import os,re,secrets,subprocess,zipfile
from pathlib import Path
from flask import Flask,request,jsonify,send_file,send_from_directory
from generator import generate_project
ROOT=Path(__file__).resolve().parent; BUILDS=ROOT/'builds'; BUILDS.mkdir(exist_ok=True); app=Flask(__name__)
def validate(c):
    c=c or {}; url=str(c.get('url','')).strip(); pkg=str(c.get('packageName','')).strip()
    if not url.startswith(('http://','https://')): raise ValueError('URL ต้องขึ้นต้นด้วย http:// หรือ https://')
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)+',pkg): raise ValueError('Package name ไม่ถูกต้อง')
    c['url']=url;c['packageName']=pkg;c['appName']=str(c.get('appName','My WebApp')).strip()[:50] or 'My WebApp';c['versionName']=str(c.get('versionName','1.0.0')).strip()[:30] or '1.0.0';c['versionCode']=max(1,int(c.get('versionCode',1)));c['minSdk']=max(21,min(35,int(c.get('minSdk',24))));return c
def create(c):
    job=BUILDS/secrets.token_hex(10);job.mkdir();project=job/'project';generate_project(c,project);return job,project
def zip_project(job,project):
    z=job/'AndroidStudioProject.zip'
    with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as f:
        for x in project.rglob('*'):
            if x.is_file() and 'build' not in x.parts and '.gradle' not in x.parts:f.write(x,x.relative_to(project))
    return z
def run_build(project):
    p=subprocess.run(['bash',str(ROOT/'build.sh'),str(project)],cwd=ROOT,capture_output=True,text=True,timeout=900);out=(p.stdout or '')+'\n'+(p.stderr or '')
    if p.returncode: raise RuntimeError(out[-14000:])
    apk=project/'app/build/outputs/apk/debug/app-debug.apk';aab=project/'app/build/outputs/bundle/debug/app-debug.aab'
    if not apk.exists() or not aab.exists(): raise RuntimeError('Gradle จบแต่ไม่พบ APK/AAB output')
    return out
@app.get('/')
def index(): return send_from_directory(ROOT,'index.html')
@app.post('/api/build')
def api_build():
    try:
        c=validate(request.get_json(force=True));job,project=create(c);out=run_build(project);z=zip_project(job,project)
        return jsonify(log=out[-14000:],apk=f'/download/{job.name}/app-debug.apk',aab=f'/download/{job.name}/app-debug.aab',zip=f'/download/{job.name}/{z.name}')
    except subprocess.TimeoutExpired:return jsonify(error='Build timeout: เกิน 15 นาที'),504
    except Exception as e:return jsonify(error=str(e)[-14000:]),400
@app.post('/api/source')
def api_source():
    try:
        c=validate(request.get_json(force=True));job,project=create(c);z=zip_project(job,project);return jsonify(log='สร้าง Android Studio project สำเร็จ',zip=f'/download/{job.name}/{z.name}')
    except Exception as e:return jsonify(error=str(e)[-12000:]),400
@app.get('/download/<job>/<filename>')
def download(job,filename):
    if Path(filename).name!=filename:return 'Bad filename',400
    project=BUILDS/job/'project';mapping={'app-debug.apk':project/'app/build/outputs/apk/debug/app-debug.apk','app-debug.aab':project/'app/build/outputs/bundle/debug/app-debug.aab'};path=mapping.get(filename,BUILDS/job/filename)
    return send_file(path,as_attachment=True,download_name=filename) if path.exists() else ('Not found',404)
if __name__=='__main__':app.run(host=os.getenv('HOST','0.0.0.0'),port=int(os.getenv('PORT','8080')))
