#!/usr/bin/env bash
set -euo pipefail
PROJECT="${1:?project path required}"
GRADLE_VERSION="${GRADLE_VERSION:-8.11.1}"
CACHE="${HOME}/.apkcreator/gradle"
mkdir -p "$CACHE"
if command -v gradle >/dev/null 2>&1; then GRADLE_CMD="$(command -v gradle)"; else
  command -v curl >/dev/null 2>&1 || { echo 'curl is required'; exit 1; }
  command -v unzip >/dev/null 2>&1 || { echo 'unzip is required'; exit 1; }
  ZIP="$CACHE/gradle-${GRADLE_VERSION}-bin.zip"; DIR="$CACHE/gradle-${GRADLE_VERSION}"
  if [ ! -x "$DIR/bin/gradle" ]; then curl -fL --retry 3 "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -o "$ZIP"; rm -rf "$DIR.tmp"; mkdir -p "$DIR.tmp"; unzip -q "$ZIP" -d "$DIR.tmp"; mv "$DIR.tmp/gradle-${GRADLE_VERSION}" "$DIR"; rm -rf "$DIR.tmp"; fi
  GRADLE_CMD="$DIR/bin/gradle"
fi
command -v java >/dev/null 2>&1 || { echo 'JDK 17 is required'; exit 1; }
JAVA_MAJOR="$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | cut -d. -f1)"
[ "$JAVA_MAJOR" = "17" ] || { echo "JDK 17 required; found Java $JAVA_MAJOR"; exit 1; }
cd "$PROJECT"
"$GRADLE_CMD" --no-daemon --stacktrace assembleDebug bundleDebug
