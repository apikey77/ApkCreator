from pathlib import Path
import html,re
AGP='8.9.2';KOTLIN='2.0.21'
def esc(v):return html.escape(str(v),quote=True)
def generate_project(c,root):
 root=Path(root);pkg=c['packageName'];app=c['appName'];lang=c.get('language','java');kind='java' if lang=='java' else 'kotlin';src=root/f'app/src/main/{kind}/{pkg.replace(".","/")}';res=root/'app/src/main/res'
 for d in [src,res/'layout',res/'values',res/'drawable']:d.mkdir(parents=True,exist_ok=True)
 (root/'settings.gradle').write_text(f'''pluginManagement {{ repositories {{ google(); mavenCentral(); gradlePluginPortal() }} }}
dependencyResolutionManagement {{ repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories {{ google(); mavenCentral() }} }}
rootProject.name="{re.sub(r"[^A-Za-z0-9_-]","_",app)}"\ninclude(":app")\n''')
 (root/'build.gradle').write_text(f'''plugins {{ id "com.android.application" version "{AGP}" apply false; id "org.jetbrains.kotlin.android" version "{KOTLIN}" apply false }}\n''')
 (root/'gradle.properties').write_text('org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nandroid.nonTransitiveRClass=true\n')
 deps=['implementation "androidx.appcompat:appcompat:1.7.0"','implementation "com.google.android.material:material:1.12.0"']
 if c.get('pullRefresh'):deps.append('implementation "androidx.swiperefreshlayout:swiperefreshlayout:1.1.0"')
 if c.get('biometric'):deps.append('implementation "androidx.biometric:biometric:1.1.0"')
 if c.get('admob'):deps.append('implementation "com.google.android.gms:play-services-ads:23.6.0"')
 kp='\n    id "org.jetbrains.kotlin.android"' if lang=='kotlin' else '';ko='\n    kotlinOptions { jvmTarget = "17" }' if lang=='kotlin' else ''
 (root/'app/build.gradle').write_text(f'''plugins {{ id "com.android.application"{kp} }}
android {{ namespace "{pkg}"; compileSdk 35; defaultConfig {{ applicationId "{pkg}"; minSdk {c['minSdk']}; targetSdk 35; versionCode {c['versionCode']}; versionName "{esc(c['versionName'])}" }}; buildTypes {{ release {{ minifyEnabled false; proguardFiles getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro" }} }}; compileOptions {{ sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }}{ko} }}
dependencies {{ {''.join(d+'; ' for d in deps)} }}\n''')
 perms=['<uses-permission android:name="android.permission.INTERNET"/>','<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>']
 if c.get('camera'):perms.append('<uses-permission android:name="android.permission.CAMERA"/>')
 if c.get('location'):perms.append('<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>')
 if c.get('biometric'):perms.append('<uses-permission android:name="android.permission.USE_BIOMETRIC"/>')
 meta=f'<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="{esc(c.get("admobAppId",""))}"/>' if c.get('admob') else ''
 orient={'portrait':'portrait','landscape':'landscape','sensor':'fullSensor'}[c.get('orientation','portrait')]
 (root/'app/src/main/AndroidManifest.xml').write_text(f'''<manifest xmlns:android="http://schemas.android.com/apk/res/android">{''.join(perms)}<application android:allowBackup="true" android:label="{esc(app)}" android:theme="@style/AppTheme" android:icon="@drawable/ic_launcher">{meta}<activity android:name=".MainActivity" android:screenOrientation="{orient}" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>''')
 (res/'values/colors.xml').write_text(f'<resources><color name="primary">{esc(c.get("color","#3ddc84"))}</color></resources>')
 (res/'values/themes.xml').write_text('<resources><style name="AppTheme" parent="Theme.Material3.DayNight.NoActionBar"><item name="android:colorAccent">@color/primary</item></style></resources>')
 (res/'drawable/ic_launcher.xml').write_text(f'<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108"><path android:fillColor="{esc(c.get("color","#3ddc84"))}" android:pathData="M0,0h108v108h-108z"/></vector>')
 (res/'layout/activity_main.xml').write_text(layout(c));(src/f'MainActivity.{kind}').write_text(java(c) if lang=='java' else kotlin(c));(root/'app/proguard-rules.pro').write_text('')
def layout(c):
 web='<WebView android:id="@+id/webview" android:layout_width="match_parent" android:layout_height="match_parent"/>'
 if c.get('pullRefresh'):web='<androidx.swiperefreshlayout.widget.SwipeRefreshLayout android:id="@+id/swipeRefresh" android:layout_width="match_parent" android:layout_height="match_parent">'+web+'</androidx.swiperefreshlayout.widget.SwipeRefreshLayout>'
 ad=f'<com.google.android.gms.ads.AdView android:id="@+id/adView" android:layout_width="match_parent" android:layout_height="wrap_content" android:layout_alignParentBottom="true" ads:adSize="BANNER" ads:adUnitId="{esc(c.get("admobBannerId",""))}"/>' if c.get('admob') else ''
 return f'<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android" xmlns:ads="http://schemas.android.com/apk/res-auto" android:layout_width="match_parent" android:layout_height="match_parent">{web}{ad}</RelativeLayout>'
def java(c):
 return f'''package {c['packageName']};
import android.os.Bundle; import android.webkit.*; import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {{ public void onCreate(Bundle b){{super.onCreate(b);setContentView(R.layout.activity_main);WebView w=findViewById(R.id.webview);w.getSettings().setJavaScriptEnabled({str(bool(c.get('javascript',True))).lower()});w.getSettings().setDomStorageEnabled({str(bool(c.get('javascript',True))).lower()});w.setWebViewClient(new WebViewClient());w.setWebChromeClient(new WebChromeClient());w.loadUrl("{c['url']}");}} @Override public void onBackPressed(){{WebView w=findViewById(R.id.webview);if(w.canGoBack())w.goBack();else super.onBackPressed();}} }}'''
def kotlin(c):
 return f'''package {c['packageName']}
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity:AppCompatActivity(){{override fun onCreate(b:Bundle?){{super.onCreate(b);setContentView(R.layout.activity_main);val w=findViewById<WebView>(R.id.webview);w.settings.javaScriptEnabled={str(bool(c.get('javascript',True))).lower()};w.settings.domStorageEnabled={str(bool(c.get('javascript',True))).lower()};w.webViewClient=WebViewClient();w.webChromeClient=WebChromeClient();w.loadUrl("{c['url']}")}}}}'''
